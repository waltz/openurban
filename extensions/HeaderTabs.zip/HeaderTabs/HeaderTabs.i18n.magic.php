<?php
/**
 *  Magic words for extension.
 */

$magicWords = array();

/** English (English) */
$magicWords['en'] = array(
	'switchtablink' => array( 0, 'switchtablink' ),
);
